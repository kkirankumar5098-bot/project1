import { useState } from "react";
import StudyMateHero from "@/components/StudyMateHero";
import PDFUploader from "@/components/PDFUploader";
import ChatInterface from "@/components/ChatInterface";

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  status: string;
  progress: number;
}

const Index = () => {
  const [currentView, setCurrentView] = useState<'hero' | 'upload' | 'chat'>('hero');
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const handleGetStarted = () => {
    setCurrentView('upload');
  };

  const handleFilesReady = (files: UploadedFile[]) => {
    setUploadedFiles(files);
    setCurrentView('chat');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'hero':
        return <StudyMateHero onGetStarted={handleGetStarted} />;
      case 'upload':
        return (
          <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 py-16">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h1 className="text-4xl font-bold mb-4">
                  Upload Your <span className="text-academic-gradient">Study Materials</span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  Upload your PDFs, textbooks, and research papers to start your AI-powered Q&A session
                </p>
              </div>
              <PDFUploader onFilesReady={handleFilesReady} />
            </div>
          </div>
        );
      case 'chat':
        return (
          <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 py-8">
            <div className="container mx-auto px-4">
              <div className="text-center mb-8">
                <h1 className="text-3xl font-bold mb-2">
                  Ask <span className="text-academic-gradient">StudyMate</span>
                </h1>
                <p className="text-muted-foreground">
                  Your AI assistant is ready to answer questions about your documents
                </p>
              </div>
              <ChatInterface files={uploadedFiles} />
            </div>
          </div>
        );
      default:
        return <StudyMateHero onGetStarted={handleGetStarted} />;
    }
  };

  return renderContent();
};

export default Index;
