import { useState, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Upload, File, X, CheckCircle, Loader2 } from "lucide-react";

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
}

interface PDFUploaderProps {
  onFilesReady: (files: UploadedFile[]) => void;
}

export default function PDFUploader({ onFilesReady }: PDFUploaderProps) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const { toast } = useToast();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const processFile = async (file: File): Promise<UploadedFile> => {
    const uploadedFile: UploadedFile = {
      id: Math.random().toString(36).substr(2, 9),
      name: file.name,
      size: file.size,
      status: 'uploading',
      progress: 0
    };

    setFiles(prev => [...prev, uploadedFile]);

    // Simulate upload progress
    for (let progress = 0; progress <= 100; progress += 10) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setFiles(prev => prev.map(f => 
        f.id === uploadedFile.id 
          ? { ...f, progress, status: progress === 100 ? 'processing' : 'uploading' }
          : f
      ));
    }

    // Simulate processing
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setFiles(prev => prev.map(f => 
      f.id === uploadedFile.id 
        ? { ...f, status: 'completed', progress: 100 }
        : f
    ));

    return uploadedFile;
  };

  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFiles = Array.from(e.dataTransfer.files);
    const pdfFiles = droppedFiles.filter(file => file.type === 'application/pdf');

    if (pdfFiles.length === 0) {
      toast({
        title: "Invalid file type",
        description: "Please upload PDF files only.",
        variant: "destructive"
      });
      return;
    }

    if (pdfFiles.length > 5) {
      toast({
        title: "Too many files",
        description: "Please upload maximum 5 PDFs at once.",
        variant: "destructive"
      });
      return;
    }

    try {
      const processedFiles = await Promise.all(pdfFiles.map(processFile));
      onFilesReady(processedFiles);
      
      toast({
        title: "Files uploaded successfully!",
        description: `${processedFiles.length} PDF(s) ready for Q&A.`
      });
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error processing your files.",
        variant: "destructive"
      });
    }
  }, [onFilesReady, toast]);

  const handleFileInput = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    if (selectedFiles.length > 0) {
      const processedFiles = await Promise.all(selectedFiles.map(processFile));
      onFilesReady(processedFiles);
    }
  }, [onFilesReady]);

  const removeFile = useCallback((fileId: string) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  }, []);

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusIcon = (status: UploadedFile['status']) => {
    switch (status) {
      case 'uploading':
      case 'processing':
        return <Loader2 className="h-4 w-4 animate-spin text-primary" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <X className="h-4 w-4 text-destructive" />;
    }
  };

  const getStatusText = (status: UploadedFile['status']) => {
    switch (status) {
      case 'uploading': return 'Uploading...';
      case 'processing': return 'Processing...';
      case 'completed': return 'Ready';
      case 'error': return 'Error';
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Upload Area */}
      <Card className="academic-card">
        <div
          className={`relative p-8 border-2 border-dashed rounded-xl transition-all duration-300 ${
            isDragging 
              ? 'border-primary bg-primary/5 scale-[1.02]' 
              : 'border-border hover:border-primary/50'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <input
            type="file"
            multiple
            accept=".pdf"
            onChange={handleFileInput}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-academic-purple rounded-xl flex items-center justify-center mx-auto mb-4">
              <Upload className="h-8 w-8 text-white" />
            </div>
            
            <h3 className="text-xl font-semibold mb-2">Upload Your Study Materials</h3>
            <p className="text-muted-foreground mb-4">
              Drag and drop your PDF files here, or click to browse
            </p>
            
            <Button variant="academic" size="lg">
              Choose Files
            </Button>
            
            <p className="text-xs text-muted-foreground mt-4">
              Supports PDF files up to 10MB each. Maximum 5 files.
            </p>
          </div>
        </div>
      </Card>

      {/* File List */}
      {files.length > 0 && (
        <Card className="academic-card p-6">
          <h4 className="text-lg font-semibold mb-4">Uploaded Files</h4>
          <div className="space-y-4">
            {files.map((file) => (
              <div key={file.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                <div className="flex items-center space-x-4 flex-1">
                  <File className="h-8 w-8 text-primary flex-shrink-0" />
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium truncate">{file.name}</p>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(file.status)}
                        <span className="text-xs text-muted-foreground">
                          {getStatusText(file.status)}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                      
                      {file.status !== 'completed' && (
                        <div className="w-24">
                          <Progress value={file.progress} className="h-1" />
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeFile(file.id)}
                  className="ml-4 flex-shrink-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
          
          {files.every(f => f.status === 'completed') && files.length > 0 && (
            <div className="mt-6 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <p className="text-sm font-medium text-green-800 dark:text-green-200">
                  All files processed successfully! You can now start asking questions.
                </p>
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}