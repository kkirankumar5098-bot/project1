import { Button } from "@/components/ui/button";
import { BookOpen, MessageSquare, Upload, Zap } from "lucide-react";
import heroImage from "@/assets/hero-studymate.jpg";

interface StudyMateHeroProps {
  onGetStarted: () => void;
}

export default function StudyMateHero({ onGetStarted }: StudyMateHeroProps) {
  const features = [
    {
      icon: Upload,
      title: "Upload PDFs",
      description: "Upload textbooks, notes, and research papers"
    },
    {
      icon: MessageSquare,
      title: "Ask Questions",
      description: "Get instant answers from your documents"
    },
    {
      icon: Zap,
      title: "AI-Powered",
      description: "Advanced AI understands academic context"
    },
    {
      icon: BookOpen,
      title: "Study Smart",
      description: "Transform passive reading into active learning"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiMwMDAwMDAiIGZpbGwtb3BhY2l0eT0iMC4wMiI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')]" />
      
      <div className="relative z-10">
        {/* Navigation */}
        <nav className="flex items-center justify-between p-6 lg:px-8">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-academic-purple rounded-lg flex items-center justify-center">
              <BookOpen className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-academic-gradient">StudyMate</span>
          </div>
          <Button variant="academic" size="sm">
            Sign In
          </Button>
        </nav>

        {/* Hero Section */}
        <div className="mx-auto max-w-7xl px-6 lg:px-8 pt-16 pb-24">
          <div className="lg:grid lg:grid-cols-12 lg:gap-x-8 lg:gap-y-20">
            {/* Content */}
            <div className="lg:col-span-7">
              <div className="mx-auto max-w-2xl lg:mx-0 animate-fade-up">
                <h1 className="text-hero text-foreground">
                  Transform Your Study Materials with{" "}
                  <span className="text-academic-gradient">AI-Powered Q&A</span>
                </h1>
                
                <p className="mt-6 text-lg leading-8 text-muted-foreground">
                  StudyMate enables you to interact with your PDFs, textbooks, and research papers 
                  through natural conversations. Upload your documents and ask questions to get 
                  instant, contextual answers grounded in your study materials.
                </p>

                <div className="mt-10 flex items-center gap-x-6">
                  <Button 
                    onClick={onGetStarted}
                    variant="hero" 
                    size="lg"
                    className="animate-scale-in"
                  >
                    Get Started Free
                  </Button>
                  <Button variant="ghost" size="lg">
                    Watch Demo
                  </Button>
                </div>

                {/* Stats */}
                <div className="mt-16 grid grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">10K+</div>
                    <div className="text-sm text-muted-foreground">Documents Processed</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">50K+</div>
                    <div className="text-sm text-muted-foreground">Questions Answered</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">95%</div>
                    <div className="text-sm text-muted-foreground">Accuracy Rate</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Hero Image */}
            <div className="lg:col-span-5 mt-16 lg:mt-0">
              <div className="relative animate-fade-up" style={{ animationDelay: '0.2s' }}>
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-academic-purple/20 rounded-2xl blur-3xl transform rotate-6" />
                <img
                  src={heroImage}
                  alt="StudyMate AI Interface"
                  className="relative w-full rounded-2xl shadow-2xl hover-lift"
                />
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="mt-32">
            <h2 className="text-3xl font-bold tracking-tight text-center mb-16">
              How StudyMate <span className="text-academic-gradient">Works</span>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div 
                  key={feature.title}
                  className="academic-card p-6 text-center hover-lift animate-fade-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-primary to-academic-purple rounded-lg flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}