import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, User, BookOpen, Lightbulb, FileText } from "lucide-react";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  sources?: string[];
}

interface UploadedFile {
  id: string;
  name: string;
  size: number;
  status: string;
  progress: number;
}

interface ChatInterfaceProps {
  files: UploadedFile[];
}

export default function ChatInterface({ files }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Suggested questions based on academic context
  const suggestedQuestions = [
    "What are the main concepts covered in these documents?",
    "Can you summarize the key findings from chapter 3?",
    "What is the methodology used in this research?",
    "How does this relate to previous studies mentioned?",
    "What are the practical applications of these theories?",
    "Can you explain this concept in simpler terms?"
  ];

  // Simulated AI responses for demonstration
  const simulateAIResponse = async (question: string): Promise<Message> => {
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    const responses = [
      {
        content: "Based on your uploaded documents, this concept refers to the fundamental principles of machine learning algorithms. The documents highlight three key approaches: supervised learning, unsupervised learning, and reinforcement learning. Each method has distinct applications and is suitable for different types of data analysis tasks.",
        sources: files.slice(0, 2).map(f => f.name)
      },
      {
        content: "The research methodology outlined in your materials follows a quantitative approach with experimental design. The study employs statistical analysis using ANOVA and regression models to validate the hypotheses. The sample size of 300 participants provides adequate statistical power for the conclusions drawn.",
        sources: files.slice(0, 1).map(f => f.name)
      },
      {
        content: "According to the theoretical framework presented in your documents, this phenomenon can be explained through the lens of cognitive psychology. The authors reference several seminal works by Piaget and Vygotsky to support their arguments about developmental learning processes.",
        sources: files.slice(1, 3).map(f => f.name)
      }
    ];

    const randomResponse = responses[Math.floor(Math.random() * responses.length)];
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      type: 'assistant',
      content: randomResponse.content,
      timestamp: new Date(),
      sources: randomResponse.sources
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Math.random().toString(36).substr(2, 9),
      type: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const aiResponse = await simulateAIResponse(input);
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error generating response:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    setInput(question);
  };

  // Auto-scroll to bottom when new messages are added
  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  // Welcome message when files are ready
  useEffect(() => {
    if (files.length > 0 && messages.length === 0) {
      const welcomeMessage: Message = {
        id: 'welcome',
        type: 'assistant',
        content: `Hello! I've analyzed ${files.length} document(s) and I'm ready to answer your questions. You can ask me about any concepts, theories, or specific information from your uploaded materials. What would you like to know?`,
        timestamp: new Date(),
        sources: files.map(f => f.name)
      };
      setMessages([welcomeMessage]);
    }
  }, [files, messages.length]);

  return (
    <div className="w-full max-w-4xl mx-auto h-[80vh] flex flex-col">
      {/* Header */}
      <Card className="academic-card p-4 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-primary to-academic-purple rounded-lg flex items-center justify-center">
              <Bot className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">StudyMate AI Assistant</h3>
              <p className="text-sm text-muted-foreground">
                {files.length} document(s) loaded and ready
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {files.slice(0, 3).map((file, index) => (
              <Badge key={file.id} variant="secondary" className="text-xs">
                <FileText className="h-3 w-3 mr-1" />
                {file.name.length > 15 ? `${file.name.substring(0, 15)}...` : file.name}
              </Badge>
            ))}
            {files.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{files.length - 3} more
              </Badge>
            )}
          </div>
        </div>
      </Card>

      {/* Chat Messages */}
      <Card className="academic-card flex-1 flex flex-col">
        <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-4 rounded-xl ${
                    message.type === 'user'
                      ? 'bg-primary text-primary-foreground ml-4'
                      : 'bg-muted/50 mr-4'
                  }`}
                >
                  <div className="flex items-start space-x-3">
                    {message.type === 'assistant' && (
                      <div className="w-6 h-6 bg-gradient-to-br from-primary to-academic-purple rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <Bot className="h-4 w-4 text-white" />
                      </div>
                    )}
                    {message.type === 'user' && (
                      <div className="w-6 h-6 bg-card rounded-full flex items-center justify-center flex-shrink-0 mt-1 order-2">
                        <User className="h-4 w-4 text-card-foreground" />
                      </div>
                    )}
                    
                    <div className={message.type === 'user' ? 'order-1' : ''}>
                      <p className="text-sm leading-relaxed">{message.content}</p>
                      
                      {message.sources && (
                        <div className="mt-3 pt-3 border-t border-border/50">
                          <p className="text-xs text-muted-foreground mb-2 flex items-center">
                            <BookOpen className="h-3 w-3 mr-1" />
                            Sources:
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {message.sources.map((source, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {source}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <p className="text-xs text-muted-foreground mt-2">
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="max-w-[80%] p-4 rounded-xl bg-muted/50 mr-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-6 h-6 bg-gradient-to-br from-primary to-academic-purple rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-white animate-pulse" />
                    </div>
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-primary/60 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Suggested Questions */}
        {messages.length <= 1 && (
          <div className="p-4 border-t border-border/50">
            <div className="flex items-center space-x-2 mb-3">
              <Lightbulb className="h-4 w-4 text-academic-gold" />
              <span className="text-sm font-medium">Suggested Questions:</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {suggestedQuestions.slice(0, 4).map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-left h-auto p-3 whitespace-normal hover:bg-primary/5"
                  onClick={() => handleSuggestedQuestion(question)}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Input Form */}
        <div className="p-4 border-t border-border/50">
          <form onSubmit={handleSubmit} className="flex space-x-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question about your documents..."
              className="flex-1 academic-input"
              disabled={isLoading || files.length === 0}
            />
            <Button 
              type="submit" 
              disabled={!input.trim() || isLoading || files.length === 0}
              variant="gradient"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
          
          {files.length === 0 && (
            <p className="text-xs text-muted-foreground mt-2">
              Upload PDF documents to start asking questions
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}